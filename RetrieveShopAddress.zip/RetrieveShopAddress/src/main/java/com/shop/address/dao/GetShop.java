package com.shop.address.dao;

public interface GetShop  {
	public String getShopsList(String Longitude,String Latitude);
}
