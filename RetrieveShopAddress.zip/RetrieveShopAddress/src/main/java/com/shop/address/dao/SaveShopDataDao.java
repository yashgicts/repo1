package com.shop.address.dao;

import com.shop.address.vo.ShopsVO;

public interface SaveShopDataDao {
	public boolean saveShopInfo(ShopsVO shopInfo);
}
